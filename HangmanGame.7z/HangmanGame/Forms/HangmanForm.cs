﻿using System;
using System.Drawing;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HangmanGame.Forms
{
    public partial class HangmanForm : Form
    {
        private Task receiveTask;
        private bool connect;

        public HangmanForm()
        {
            InitializeComponent();
            setControlsEnabled(gameControl.TabPages[1].Controls, false);
            btnStart.Enabled = false;
            btnStop.Enabled = false;
            btnSend.Enabled = false;
            errorMessage.Text = "";
        }

        public int localPort; // порт для приема сообщений
        public int remotePort; // порт для отправки сообщений
        public string userName;
        public string userPass;
        private Connection.Connect cnct = new Connection.Connect();

        private void FieldTextChanged(object sender, EventArgs e)
        {
            if (txtLogin.Text.Length > 0 && txtPassword.Text.Length > 0 && txtLocalport.Text.Length > 0 && txtRemoteport.Text.Length > 0)
            {
                btnStart.Enabled = true;
            }
            else errorMessage.Text = "all fields must be filled";
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            userName = txtLogin.Text;
            userPass = txtPassword.Text;
            remotePort = Convert.ToInt32(txtRemoteport.Text);
            localPort = Convert.ToInt32(txtLocalport.Text);
            cnct.CheckLogin(ref userName, ref userPass, out bool access, out string report);
            if (access == true)
            {
                try
                {
                    connect = cnct.StartServer(remotePort, localPort);
                    btnStartGame.Enabled = true;
                    // запускаем задачу на прием сообщений
                    receiveTask = new Task(ReceiveMessages);
                    receiveTask.Start();

                }
                catch (Exception ex)
                {
                    errorMessage.Text = ex.Message;
                }

                btnStart.Enabled = false;
                btnStop.Enabled = true;
                btnSend.Enabled = true;
                txtLogin.ReadOnly = true;
                txtPassword.ReadOnly = true;
            }
            errorMessage.Text = report;
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            connect = cnct.StopServer();
            setControlsEnabled(gameControl.TabPages[1].Controls, false);
            btnStart.Enabled = true;
            btnStop.Enabled = false;
            btnSend.Enabled = false;
            txtLogin.ReadOnly = false;
            txtPassword.ReadOnly = false;
        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            string message = String.Format("{0}: {1}", userName, txtMessage.Text);
            cnct.SendMessage(message);
            txtMessage.Clear();
        }

        // обработчик события закрытия формы
        private void HangmanForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            cnct.StopServer();

            btnStart.Enabled = true;
            btnStop.Enabled = false;
            btnSend.Enabled = false;
            txtLogin.ReadOnly = false;
            txtPassword.ReadOnly = false;
        }

        private void ReceiveMessages()
        {
            while (connect)
            {
                string time = DateTime.Now.ToShortTimeString();
                string message = time + ": " + cnct.StartReceiving() + Environment.NewLine;
                // добавляем полученное сообщение в текстовое поле
                this.Invoke(new MethodInvoker(() =>
                {
                    txtChat.Text += message;
                }));
            }
        }

        // просто потому что случайно, и если это удалить, он удаляет содержимое формы
        private void txtLetter_TextChanged(object sender, EventArgs e)
        {

        }

        private void setControlsEnabled(Control.ControlCollection controlCollection, bool enable)
        {
            foreach (Control currControl in controlCollection)
            {
                currControl.Enabled = enable;
            }
        }


  // эта часть кода отвечает за игровой процесс 



        public string wordText; // слово для угадывания
        public char[] wordLetters; // массив букв слова для угадывания
        public string guessWord = ""; // угаданное слово
        public int attempt; //количество неудачных попыток
        bool gameProcess; //нужна для игры с соперником, но не в этот раз

        private void btnStartGame_Click(object sender, EventArgs e)
        {
            lblWord.Text = "";
            txtWord.Clear();
            guessWord = "";
            pictureBox.Image = null;
            setControlsEnabled(gameControl.TabPages[1].Controls, true);
            // сообщаем серверу что мы начали игру. Если игра еще не была начата соперником, то первый ход предоставляется игроку
            gameProcess = true;
        }

        private void btnEnterWord_Click(object sender, EventArgs e)
        {
            wordText = txtWord.Text;
            attempt = 0;
            // Создаем массив букв длины, соответствующей длине входного слова
            // выводим каждую букву как точку
            wordLetters = new char[wordText.Length];
            for (int i = 0; i < wordText.Length; i++)
            {
                lblWord.Text += " . ";
                wordLetters[i] = '.';
            }
        }

        private void btnEnterLetter_Click(object sender, EventArgs e)
        {
            if (txtLetter.Text.Length == 1)
            {
                char letter = txtLetter.Text[0];
                checkLetter(letter);
            }
            else if (txtLetter.Text.Length > 1)
            {
                string word = txtLetter.Text;
                checkWord(word);
            }
            txtLetter.Clear();
        }

        public void checkLetter(char letter)
        {
            bool hit = false; // индикатор попадания
            // проверяем каждую букву входного слова
            for (int i = 0; i < wordText.Length; i++)
            {
                if (letter == wordText[i])
                {
                    hit = true;
                    wordLetters[i] = wordText[i]; // заменяем точку на букву
                }
                guessWord += wordLetters[i]; // 
            }
            // если угадали букву, то выводим угаданные буквы и проверяем на выигрыш
            if (hit == true)
            {
                lblWord.Text = guessWord; // показываем результат
                checkWin(guessWord);
                guessWord = null;
            }
            // если не угадали, то увеличиваем счетчик попыток и проверяем на проигрыш
            else
            {
                attempt++;
                checkAttempt(attempt);
            }
        }

        //
        public void checkWord(string word)
        {
            if (word.Length == wordText.Length)
            {
                if (word == wordText)
                    checkWin(word);
            }
            else
            {
                attempt++;
                checkAttempt(attempt);
            }
        }

        public void checkWin(string guessWord)
        {
            if (guessWord == wordText)
            {
                MessageBox.Show("You win!");
                gameProcess = false;
                setControlsEnabled(gameControl.TabPages[1].Controls, false);
                btnStartGame.Enabled = true;
            }
        }

        // проверка счетчика попыток на достижение 10 и проигрыш
        public void checkAttempt(int attempt)
        {
            string attemptImg = "Images/" + attempt.ToString() + ".png";
            pictureBox.Image = new Bitmap(attemptImg);

            if (attempt == 10)
            {
                MessageBox.Show("You loose!");
                lblWord.Text = wordText;
                gameProcess = false;
                setControlsEnabled(gameControl.TabPages[1].Controls, false);
                btnStartGame.Enabled = true;
            }
        }
    }
}


