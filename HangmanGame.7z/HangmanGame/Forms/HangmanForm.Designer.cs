﻿namespace HangmanGame.Forms
{
    partial class HangmanForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Label label4;
            System.Windows.Forms.Label label3;
            System.Windows.Forms.Label label2;
            System.Windows.Forms.Label label1;
            System.Windows.Forms.Label label5;
            System.Windows.Forms.Label label7;
            System.Windows.Forms.Label label8;
            this.gameControl = new System.Windows.Forms.TabControl();
            this.connectPage = new System.Windows.Forms.TabPage();
            this.errorMessage = new System.Windows.Forms.Label();
            this.txtChat = new System.Windows.Forms.TextBox();
            this.txtMessage = new System.Windows.Forms.TextBox();
            this.btnSend = new System.Windows.Forms.Button();
            this.btnStop = new System.Windows.Forms.Button();
            this.btnStart = new System.Windows.Forms.Button();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.txtRemoteport = new System.Windows.Forms.TextBox();
            this.txtLocalport = new System.Windows.Forms.TextBox();
            this.txtLogin = new System.Windows.Forms.TextBox();
            this.gamePage = new System.Windows.Forms.TabPage();
            this.btnStartGame = new System.Windows.Forms.Button();
            this.btnEnterLetter = new System.Windows.Forms.Button();
            this.txtLetter = new System.Windows.Forms.TextBox();
            this.btnEnterWord = new System.Windows.Forms.Button();
            this.txtWord = new System.Windows.Forms.TextBox();
            this.pictureBox = new System.Windows.Forms.PictureBox();
            this.lblWord = new System.Windows.Forms.Label();
            label4 = new System.Windows.Forms.Label();
            label3 = new System.Windows.Forms.Label();
            label2 = new System.Windows.Forms.Label();
            label1 = new System.Windows.Forms.Label();
            label5 = new System.Windows.Forms.Label();
            label7 = new System.Windows.Forms.Label();
            label8 = new System.Windows.Forms.Label();
            this.gameControl.SuspendLayout();
            this.connectPage.SuspendLayout();
            this.gamePage.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new System.Drawing.Point(16, 197);
            label4.Name = "label4";
            label4.Size = new System.Drawing.Size(62, 13);
            label4.TabIndex = 17;
            label4.Text = "Remoteport";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new System.Drawing.Point(16, 155);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(51, 13);
            label3.TabIndex = 18;
            label3.Text = "Localport";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new System.Drawing.Point(16, 112);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(53, 13);
            label2.TabIndex = 16;
            label2.Text = "Password";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new System.Drawing.Point(16, 69);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(33, 13);
            label1.TabIndex = 8;
            label1.Text = "Login";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new System.Drawing.Font("Minion Pro", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            label5.ForeColor = System.Drawing.Color.SeaGreen;
            label5.Location = new System.Drawing.Point(13, 16);
            label5.Name = "label5";
            label5.Size = new System.Drawing.Size(378, 36);
            label5.TabIndex = 21;
            label5.Text = "Log in and choose your opponent";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new System.Drawing.Point(22, 240);
            label7.Name = "label7";
            label7.Size = new System.Drawing.Size(76, 13);
            label7.TabIndex = 4;
            label7.Text = "Enter the word";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new System.Drawing.Point(22, 355);
            label8.Name = "label8";
            label8.Size = new System.Drawing.Size(76, 13);
            label8.TabIndex = 4;
            label8.Text = "Enter the letter";
            // 
            // gameControl
            // 
            this.gameControl.Controls.Add(this.connectPage);
            this.gameControl.Controls.Add(this.gamePage);
            this.gameControl.Location = new System.Drawing.Point(12, 12);
            this.gameControl.Name = "gameControl";
            this.gameControl.SelectedIndex = 0;
            this.gameControl.Size = new System.Drawing.Size(776, 461);
            this.gameControl.TabIndex = 0;
            // 
            // connectPage
            // 
            this.connectPage.Controls.Add(this.errorMessage);
            this.connectPage.Controls.Add(label5);
            this.connectPage.Controls.Add(this.txtChat);
            this.connectPage.Controls.Add(this.txtMessage);
            this.connectPage.Controls.Add(label4);
            this.connectPage.Controls.Add(label3);
            this.connectPage.Controls.Add(label2);
            this.connectPage.Controls.Add(this.btnSend);
            this.connectPage.Controls.Add(this.btnStop);
            this.connectPage.Controls.Add(this.btnStart);
            this.connectPage.Controls.Add(this.txtPassword);
            this.connectPage.Controls.Add(this.txtRemoteport);
            this.connectPage.Controls.Add(this.txtLocalport);
            this.connectPage.Controls.Add(this.txtLogin);
            this.connectPage.Controls.Add(label1);
            this.connectPage.Location = new System.Drawing.Point(4, 22);
            this.connectPage.Name = "connectPage";
            this.connectPage.Padding = new System.Windows.Forms.Padding(3);
            this.connectPage.Size = new System.Drawing.Size(768, 435);
            this.connectPage.TabIndex = 0;
            this.connectPage.Text = "Connection";
            this.connectPage.UseVisualStyleBackColor = true;
            // 
            // errorMessage
            // 
            this.errorMessage.AutoSize = true;
            this.errorMessage.Location = new System.Drawing.Point(16, 273);
            this.errorMessage.Name = "errorMessage";
            this.errorMessage.Size = new System.Drawing.Size(35, 13);
            this.errorMessage.TabIndex = 22;
            this.errorMessage.Text = "label6";
            // 
            // txtChat
            // 
            this.txtChat.Location = new System.Drawing.Point(254, 174);
            this.txtChat.Multiline = true;
            this.txtChat.Name = "txtChat";
            this.txtChat.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtChat.Size = new System.Drawing.Size(491, 237);
            this.txtChat.TabIndex = 20;
            // 
            // txtMessage
            // 
            this.txtMessage.Location = new System.Drawing.Point(254, 66);
            this.txtMessage.Multiline = true;
            this.txtMessage.Name = "txtMessage";
            this.txtMessage.Size = new System.Drawing.Size(491, 58);
            this.txtMessage.TabIndex = 19;
            // 
            // btnSend
            // 
            this.btnSend.Location = new System.Drawing.Point(670, 130);
            this.btnSend.Name = "btnSend";
            this.btnSend.Size = new System.Drawing.Size(75, 23);
            this.btnSend.TabIndex = 14;
            this.btnSend.Text = "Send";
            this.btnSend.UseVisualStyleBackColor = true;
            this.btnSend.Click += new System.EventHandler(this.btnSend_Click);
            // 
            // btnStop
            // 
            this.btnStop.Location = new System.Drawing.Point(145, 238);
            this.btnStop.Name = "btnStop";
            this.btnStop.Size = new System.Drawing.Size(75, 23);
            this.btnStop.TabIndex = 15;
            this.btnStop.Text = "Stop";
            this.btnStop.UseVisualStyleBackColor = true;
            this.btnStop.Click += new System.EventHandler(this.btnStop_Click);
            // 
            // btnStart
            // 
            this.btnStart.Location = new System.Drawing.Point(19, 238);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(75, 23);
            this.btnStart.TabIndex = 13;
            this.btnStart.Text = "Start";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // txtPassword
            // 
            this.txtPassword.Location = new System.Drawing.Point(99, 109);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.Size = new System.Drawing.Size(121, 20);
            this.txtPassword.TabIndex = 9;
            this.txtPassword.TextChanged += new System.EventHandler(this.FieldTextChanged);
            // 
            // txtRemoteport
            // 
            this.txtRemoteport.Location = new System.Drawing.Point(99, 194);
            this.txtRemoteport.Name = "txtRemoteport";
            this.txtRemoteport.Size = new System.Drawing.Size(121, 20);
            this.txtRemoteport.TabIndex = 10;
            this.txtRemoteport.TextChanged += new System.EventHandler(this.FieldTextChanged);
            // 
            // txtLocalport
            // 
            this.txtLocalport.Location = new System.Drawing.Point(99, 152);
            this.txtLocalport.Name = "txtLocalport";
            this.txtLocalport.Size = new System.Drawing.Size(121, 20);
            this.txtLocalport.TabIndex = 11;
            this.txtLocalport.TextChanged += new System.EventHandler(this.FieldTextChanged);
            // 
            // txtLogin
            // 
            this.txtLogin.Location = new System.Drawing.Point(99, 66);
            this.txtLogin.Name = "txtLogin";
            this.txtLogin.Size = new System.Drawing.Size(121, 20);
            this.txtLogin.TabIndex = 12;
            this.txtLogin.TextChanged += new System.EventHandler(this.FieldTextChanged);
            // 
            // gamePage
            // 
            this.gamePage.Controls.Add(this.btnStartGame);
            this.gamePage.Controls.Add(label8);
            this.gamePage.Controls.Add(label7);
            this.gamePage.Controls.Add(this.btnEnterLetter);
            this.gamePage.Controls.Add(this.txtLetter);
            this.gamePage.Controls.Add(this.btnEnterWord);
            this.gamePage.Controls.Add(this.txtWord);
            this.gamePage.Controls.Add(this.pictureBox);
            this.gamePage.Controls.Add(this.lblWord);
            this.gamePage.Location = new System.Drawing.Point(4, 22);
            this.gamePage.Name = "gamePage";
            this.gamePage.Padding = new System.Windows.Forms.Padding(3);
            this.gamePage.Size = new System.Drawing.Size(768, 435);
            this.gamePage.TabIndex = 1;
            this.gamePage.Text = "Game";
            this.gamePage.UseVisualStyleBackColor = true;
            // 
            // btnStartGame
            // 
            this.btnStartGame.Location = new System.Drawing.Point(25, 32);
            this.btnStartGame.Name = "btnStartGame";
            this.btnStartGame.Size = new System.Drawing.Size(75, 23);
            this.btnStartGame.TabIndex = 24;
            this.btnStartGame.Text = "Start Game!";
            this.btnStartGame.UseVisualStyleBackColor = true;
            this.btnStartGame.Click += new System.EventHandler(this.btnStartGame_Click);
            // 
            // btnEnterLetter
            // 
            this.btnEnterLetter.Location = new System.Drawing.Point(25, 397);
            this.btnEnterLetter.Name = "btnEnterLetter";
            this.btnEnterLetter.Size = new System.Drawing.Size(75, 23);
            this.btnEnterLetter.TabIndex = 3;
            this.btnEnterLetter.Text = "Try!";
            this.btnEnterLetter.UseVisualStyleBackColor = true;
            this.btnEnterLetter.Click += new System.EventHandler(this.btnEnterLetter_Click);
            // 
            // txtLetter
            // 
            this.txtLetter.Location = new System.Drawing.Point(25, 371);
            this.txtLetter.Name = "txtLetter";
            this.txtLetter.Size = new System.Drawing.Size(154, 20);
            this.txtLetter.TabIndex = 2;
            this.txtLetter.TextChanged += new System.EventHandler(this.txtLetter_TextChanged);
            // 
            // btnEnterWord
            // 
            this.btnEnterWord.Location = new System.Drawing.Point(25, 282);
            this.btnEnterWord.Name = "btnEnterWord";
            this.btnEnterWord.Size = new System.Drawing.Size(75, 23);
            this.btnEnterWord.TabIndex = 3;
            this.btnEnterWord.Text = "Ready";
            this.btnEnterWord.UseVisualStyleBackColor = true;
            this.btnEnterWord.Click += new System.EventHandler(this.btnEnterWord_Click);
            // 
            // txtWord
            // 
            this.txtWord.Location = new System.Drawing.Point(25, 256);
            this.txtWord.Name = "txtWord";
            this.txtWord.Size = new System.Drawing.Size(152, 20);
            this.txtWord.TabIndex = 2;
            // 
            // pictureBox
            // 
            this.pictureBox.Location = new System.Drawing.Point(384, 92);
            this.pictureBox.Name = "pictureBox";
            this.pictureBox.Size = new System.Drawing.Size(360, 330);
            this.pictureBox.TabIndex = 1;
            this.pictureBox.TabStop = false;
            // 
            // lblWord
            // 
            this.lblWord.BackColor = System.Drawing.Color.LemonChiffon;
            this.lblWord.Font = new System.Drawing.Font("Minion Pro", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblWord.ForeColor = System.Drawing.Color.SeaGreen;
            this.lblWord.Location = new System.Drawing.Point(25, 92);
            this.lblWord.Name = "lblWord";
            this.lblWord.Size = new System.Drawing.Size(334, 100);
            this.lblWord.TabIndex = 0;
            this.lblWord.Text = " ";
            this.lblWord.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // HangmanForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gold;
            this.ClientSize = new System.Drawing.Size(800, 485);
            this.Controls.Add(this.gameControl);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "HangmanForm";
            this.Text = "HANGMAN";
            this.gameControl.ResumeLayout(false);
            this.connectPage.ResumeLayout(false);
            this.connectPage.PerformLayout();
            this.gamePage.ResumeLayout(false);
            this.gamePage.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl gameControl;
        private System.Windows.Forms.TabPage connectPage;
        private System.Windows.Forms.TabPage gamePage;
        private System.Windows.Forms.Label errorMessage;
        private System.Windows.Forms.TextBox txtChat;
        private System.Windows.Forms.TextBox txtMessage;
        private System.Windows.Forms.Button btnSend;
        private System.Windows.Forms.Button btnStop;
        private System.Windows.Forms.Button btnStart;
        public System.Windows.Forms.TextBox txtPassword;
        public System.Windows.Forms.TextBox txtRemoteport;
        public System.Windows.Forms.TextBox txtLocalport;
        public System.Windows.Forms.TextBox txtLogin;
        private System.Windows.Forms.Button btnEnterLetter;
        private System.Windows.Forms.TextBox txtLetter;
        private System.Windows.Forms.Button btnEnterWord;
        private System.Windows.Forms.TextBox txtWord;
        private System.Windows.Forms.PictureBox pictureBox;
        private System.Windows.Forms.Label lblWord;
        private System.Windows.Forms.Button btnStartGame;
    }
}

