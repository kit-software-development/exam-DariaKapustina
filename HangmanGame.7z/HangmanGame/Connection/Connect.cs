﻿using System;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace HangmanGame.Connection
{
    public class Connect
    {
        public UdpClient client;
        public bool connect = false;
        public const string remoteAddress = "127.0.0.1"; // хост

        public int Localport; // порт для приема сообщений
        public int Remoteport; // порт для отправки сообщений
        private string Username;

        public void CheckLogin(ref string login, ref string password, out bool access, out string report)
        {
            Username = login;
            access = false; // идентификатор установки соединения
            report = "connection complete"; // отчет о выполнении
            string path = Application.StartupPath + "\\Database\\ProjectDatabase.mdf";
            SqlConnection cn = new SqlConnection
            {
                ConnectionString =  (String.Format(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename={0}", path))
                // @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=path;Integrated Security=True;"
            };
            try
            {
                //Открыть подключение
                cn.Open();
                string select = "SELECT * FROM Users WHERE login='" + Username + "'";
                SqlCommand cmd = new SqlCommand(select, cn);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    Console.WriteLine(dr[2]);
                    if (Convert.ToString(dr[2]) == password)
                        access = true;
                    else report="wrong password";
                    //txtChat.Text += "ID: "+ dr[0]+" Login: "+ dr[1]+" Password: "+ dr[2];
                }
                else report = "wrong login";
            }
            catch (SqlException ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                cn.Close();
            }
        }
        

        public bool StartServer(int remotePort, int localPort)
        {
            Remoteport = remotePort;
            Localport = localPort;
            client = new UdpClient(localPort);
            connect = true;
            // отправляем первое сообщение о входе нового пользователя
            string message = Username + " joined";
            SendMessage(message);
            return connect;
        }
        

        public bool StopServer()
        {
            if (connect)
            {
                string message = Username + " logged out";
                SendMessage(message);

                connect = false;
                client.Close();
            }
            return connect;
        }
        // отправляем на сервер
        public void SendMessage(string message)
        {
            byte[] data = Encoding.Unicode.GetBytes(message);
            client.Send(data, data.Length, remoteAddress, Localport);
            client.Send(data, data.Length, remoteAddress, Remoteport);
        }
        
        // принимаем на сервее
        public string StartReceiving()
        {
            string message = " ";
            try
            {
                IPEndPoint remoteIp = null;
                byte[] data = client.Receive(ref remoteIp);
                message = Encoding.Unicode.GetString(data);
            }
            catch (Exception ex)
            {
                message = ex.Message;
            }
            return message;
        }

    }
}
