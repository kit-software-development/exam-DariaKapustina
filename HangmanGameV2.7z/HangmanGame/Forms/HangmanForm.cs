﻿using System;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HangmanGame.Forms
{
    public partial class HangmanForm : Form
    {
        private Task receiveTask;
        private bool connect;
        public int localPort;
        public string localIP;

        public string userName;
        public string userPass;
        public bool access;
        public string report;


        Connection.DBConnect dbcnct = new Connection.DBConnect();

        public HangmanForm()
        {
            InitializeComponent();
            setControlsEnabled(gameControl.TabPages[1].Controls, false);

            IPAddress myip = Dns.GetHostAddresses(Dns.GetHostName()).Where(address => address.AddressFamily == AddressFamily.InterNetwork).First();
            txtLocalIP.Text = Convert.ToString(myip);
            txtLocalPort.Text = "8080";

            btnStart.Enabled = false;
            btnStop.Enabled = false;
            btnSend.Enabled = false;
            errorMessage.Text = "";
        }

        private void FieldTextChanged(object sender, EventArgs e)
        {
            if (txtLogin.Text.Length > 0 && txtPassword.Text.Length > 0 && txtLocalIP.Text.Length > 0 && txtLocalPort.Text.Length > 0)
            {
                btnStart.Enabled = true;
                errorMessage.Text = null;
            }
            else errorMessage.Text = "all fields must be filled";
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            userName = txtLogin.Text;
            userPass = txtPassword.Text;
            localIP = txtLocalIP.Text;
            localPort = Convert.ToInt32(txtLocalPort.Text);

            dbcnct.CheckLogin(ref userName, ref userPass, out access, out report);
            if (access == true)
            {
                try
                {
                    StartClient(localIP, localPort);
                    btnStartGame.Enabled = true;
                }
                catch (Exception ex)
                {
                    errorMessage.Text = ex.Message;
                }

                btnStart.Enabled = false;
                btnStop.Enabled = true;
                btnSend.Enabled = true;
                txtLogin.ReadOnly = true;
                txtPassword.ReadOnly = true;
            }
            errorMessage.Text = report;
        }

        private void btnStop_Click(object sender, EventArgs e)
        {

            StopClient();

            setControlsEnabled(gameControl.TabPages[1].Controls, false);
            btnStart.Enabled = true;
            btnStop.Enabled = false;
            btnSend.Enabled = false;
            txtLogin.ReadOnly = false;
            txtPassword.ReadOnly = false;
        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            string message = String.Format("{0}: {1}", userName, txtMessage.Text);
            SendMessage(message);

            txtMessage.Clear();
        }

        // обработчик события закрытия формы
        private void HangmanForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            StopClient();

            btnStart.Enabled = true;
            btnStop.Enabled = false;
            btnSend.Enabled = false;
            txtLogin.ReadOnly = false;
            txtPassword.ReadOnly = false;
        }

        //Поток для получения сообщений с сервера
        Thread reciever = null;
        //Клиентский сокет
        Socket socketClient = null;

        public void StartClient(string ip, int port)
        {
            IPEndPoint endpoint = new IPEndPoint(IPAddress.Parse(ip), port);
            socketClient = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            try
            {
                socketClient.Connect(endpoint);
            }
            catch (SocketException ex)
            {
                ShowMessage(ex.Message);
            }
            catch (Exception ex)
            {
                ShowMessage(ex.Message);
            }

            reciever = new Thread(Recieving);
            reciever.IsBackground = true;
            reciever.Start();
        }

        //Отправка текстового сообщения на сервер
        public void SendMessage(string message)
        {
            byte[] buffer = Encoding.UTF8.GetBytes(message);
            byte[] buff = new byte[buffer.Length];
            try
            {
                socketClient.Send(buff);
                ShowMessage(string.Format("{0}：{1}", socketClient.RemoteEndPoint.ToString(), message));
            }
            catch (SocketException ex)
            {
                ShowMessage(ex.Message);
            }
            catch (Exception ex)
            {
                ShowMessage(ex.Message);
            }
        }

        public void StopClient()
        {
            socketClient.Close();
        }


        void Recieving()
        {
            while (true)
            {
                byte[] buffer = new byte[2048];
                int length = 0;
                try
                {
                    length = socketClient.Receive(buffer);
                }
                catch (SocketException ex)
                {
                    ShowMessage(ex.Message);
                    break;
                }
                catch (Exception ex)
                {
                    ShowMessage(ex.Message);
                    break;
                }

                //Преобразование элементов массива в строку
                string message = Encoding.UTF8.GetString(buffer, 0, length);
                ShowMessage(string.Format("{0}：{1}", socketClient.RemoteEndPoint.ToString(), message));
            }
        }


        public void ShowMessage(string msg)
        {
            string time = DateTime.Now.ToShortTimeString();
            string message = time + "  " + msg;
            Console.WriteLine(message);
        }








        public class GameController
        {

        }

        // просто потому что случайно, и если это удалить, он удаляет содержимое формы
        private void txtLetter_TextChanged(object sender, EventArgs e)
        {

        }

        private void setControlsEnabled(Control.ControlCollection controlCollection, bool enable)
        {
            foreach (Control currControl in controlCollection)
            {
                currControl.Enabled = enable;
            }
        }


        // эта часть кода отвечает за игровой процесс 



        public string wordText; // слово для угадывания
        public char[] wordLetters; // массив букв слова для угадывания
        public string guessWord = ""; // угаданное слово
        public int attempt; //количество неудачных попыток
        bool gameProcess; //нужна для игры с соперником, но не в этот раз

        private void btnStartGame_Click(object sender, EventArgs e)
        {
            lblWord.Text = "";
            txtWord.Clear();
            guessWord = "";
            pictureBox.Image = null;
            setControlsEnabled(gameControl.TabPages[1].Controls, true);
            // сообщаем серверу что мы начали игру. Если игра еще не была начата соперником, то первый ход предоставляется игроку
            gameProcess = true;
        }

        private void btnEnterWord_Click(object sender, EventArgs e)
        {
            wordText = txtWord.Text;
            attempt = 0;
            // Создаем массив букв длины, соответствующей длине входного слова
            // выводим каждую букву как точку
            wordLetters = new char[wordText.Length];
            for (int i = 0; i < wordText.Length; i++)
            {
                lblWord.Text += " . ";
                wordLetters[i] = '.';
            }
        }

        private void btnEnterLetter_Click(object sender, EventArgs e)
        {
            if (txtLetter.Text.Length == 1)
            {
                char letter = txtLetter.Text[0];
                checkLetter(letter);
            }
            else if (txtLetter.Text.Length > 1)
            {
                string word = txtLetter.Text;
                checkWord(word);
            }
            txtLetter.Clear();
        }

        public void checkLetter(char letter)
        {
            bool hit = false; // индикатор попадания
            // проверяем каждую букву входного слова
            for (int i = 0; i < wordText.Length; i++)
            {
                if (letter == wordText[i])
                {
                    hit = true;
                    wordLetters[i] = wordText[i]; // заменяем точку на букву
                }
                guessWord += wordLetters[i]; // 
            }
            // если угадали букву, то выводим угаданные буквы и проверяем на выигрыш
            if (hit == true)
            {
                lblWord.Text = guessWord; // показываем результат
                checkWin(guessWord);
                guessWord = null;
            }
            // если не угадали, то увеличиваем счетчик попыток и проверяем на проигрыш
            else
            {
                attempt++;
                checkAttempt(attempt);
            }
        }

        //
        public void checkWord(string word)
        {
            if (word.Length == wordText.Length)
            {
                if (word == wordText)
                    checkWin(word);
            }
            else
            {
                attempt++;
                checkAttempt(attempt);
            }
        }

        public void checkWin(string guessWord)
        {
            if (guessWord == wordText)
            {
                MessageBox.Show("You win!");
                gameProcess = false;
                setControlsEnabled(gameControl.TabPages[1].Controls, false);
                btnStartGame.Enabled = true;
            }
        }

        // проверка счетчика попыток на достижение 10 и проигрыш
        public void checkAttempt(int attempt)
        {
            string attemptImg = "Images/" + attempt.ToString() + ".png";
            pictureBox.Image = new Bitmap(attemptImg);

            if (attempt == 10)
            {
                MessageBox.Show("You loose!");
                lblWord.Text = wordText;
                gameProcess = false;
                setControlsEnabled(gameControl.TabPages[1].Controls, false);
                btnStartGame.Enabled = true;
            }
        }
    }
}



