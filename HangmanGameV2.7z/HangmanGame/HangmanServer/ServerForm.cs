﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HangmanServer
{
    public partial class ServerForm : Form
    {
        public ServerForm()
        {
            InitializeComponent();
            IPAddress myip = Dns.GetHostAddresses(Dns.GetHostName()).Where(address => address.AddressFamily == AddressFamily.InterNetwork).First();
            txtLocalIP.Text = Convert.ToString(myip);
            txtLocalPort.Text = "8080";
            TextBox.CheckForIllegalCrossThreadCalls = false;
        }

        // Server s = new Server();
        private void btnStart_Click(object sender, EventArgs e)
        {
            StartServer(txtLocalIP.Text, Convert.ToInt32(txtLocalPort.Text));
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            StopServer();
        }

        Thread listener = null;
        Socket socketServer = null;

        //Сохраняет все сокеты для коммуникации с клиентом
        Dictionary<string, Socket> dict = new Dictionary<string, Socket>();

        //Сохраняет все потоки, отвечающие за вызов метода Recieve
        Dictionary<string, Thread> dictThread = new Dictionary<string, Thread>();

        //Открываем соединение
        public void StartServer(string ip, int port)
        {
            socketServer = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            IPEndPoint endpoint = new IPEndPoint(IPAddress.Parse(ip), port);
            try
            {
                socketServer.Bind(endpoint);
            }
            catch (SocketException ex)
            {
                ShowMessage(ex.Message);
            }
            catch (Exception ex)
            {
                ShowMessage(ex.Message);
            }

            socketServer.Listen(10);

            listener = new Thread(Listening);
            listener.IsBackground = true;
            listener.Start();

            ShowMessage("Start server");
        }

        public void StopServer()
        {
            socketServer.Close();
            ShowMessage("Stop server");
        }


        void Listening()
        {
            while (true)
            {
                Socket socketClient = null;
                try
                {
                    socketClient = socketServer.Accept();
                }
                catch (SocketException ex)
                {
                    ShowMessage(ex.Message);
                    break;
                }
                catch (Exception ex)
                {
                    ShowMessage(ex.Message);
                    break;
                }
                //Сохраняем новый сокет и загружаем его в словарь
                dict.Add(socketClient.RemoteEndPoint.ToString(), socketClient);

                //Создаем новый поток для прослушивания
                Thread reciever = new Thread(Resieving);
                reciever.IsBackground = true;
                reciever.Start(socketClient);//Поток с входящими параметрами
                dictThread.Add(socketClient.RemoteEndPoint.ToString(), reciever);

                ShowMessage(string.Format("{0} connected", socketClient.RemoteEndPoint.ToString()));
            }
        }

        void Resieving(object socketClientPara)
        {
            Socket socketClient = socketClientPara as Socket;
            while (true)
            {
                //Буфер для получения сообщений
                byte[] buffer = new byte[2048];
                int length = 0;
                try
                {
                    length = socketClient.Receive(buffer);
                }
                catch (SocketException ex)
                {
                    ShowMessage(ex.Message);

                    dict.Remove(socketClient.RemoteEndPoint.ToString());
                    dictThread.Remove(socketClient.RemoteEndPoint.ToString());
                    break;
                }
                catch (Exception ex)
                {
                    ShowMessage(ex.Message);
                    break;
                }
                string message = Encoding.Unicode.GetString(buffer, 0, length);
                ShowMessage(string.Format("{0}：{1}", socketClient.RemoteEndPoint.ToString(), message));
            }
        }

        void ShowMessage(string msg)
        {
            string time = DateTime.Now.ToShortTimeString();
            string message = time + "  " + msg + Environment.NewLine;
            Console.WriteLine(message);
            textBox1.AppendText(message);
        }
    }    
}
