﻿using System;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Threading;

namespace HangmanGame.Connection
{
    public class DBConnect
    {
        public string Username;

        public void CheckLogin(ref string login, ref string password, out bool access, out string report)
        {
            Username = login;
            access = false; // идентификатор установки соединения
            report = "db access"; // отчет о выполнении
            string path = Application.StartupPath + "\\Database\\ProjectDatabase.mdf";
            SqlConnection cn = new SqlConnection
            {
                ConnectionString = string.Format(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename={0}", path)
            };

            try
            {
                //Открыть подключение
                cn.Open();
                string select = "SELECT * FROM Users WHERE login='" + Username + "'";
                SqlCommand cmd = new SqlCommand(select, cn);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    Console.WriteLine(dr[2]);
                    if (Convert.ToString(dr[2]) == password)
                        access = true;
                    else report = "wrong password";
                    //txtChat.Text += "ID: "+ dr[0]+" Login: "+ dr[1]+" Password: "+ dr[2];
                }
                else report = "wrong login";
            }
            catch (SqlException ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                cn.Close();
            }
        }
    }
}
